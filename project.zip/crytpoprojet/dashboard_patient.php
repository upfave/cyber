<?php
session_start();
require_once 'config.php';

/*if (!isset($_SESSION['idPatient'])) {
    header("Location: index.php");
    exit;
}*/

$id = $_SESSION['idPatient'];
$patient = $pdo->query("SELECT * FROM patient WHERE idPatient = $id")->fetch();
$medecins = $pdo->query("SELECT * FROM medecin")->fetchAll();

$consultations = $pdo->prepare("SELECT c.idConsultation, c.date, c.heure, c.statut, c.notesMedecincrypte, m.nom AS medecin
    FROM consultation c
    JOIN medecin m ON c.idMedecin = m.idMedecin
    WHERE c.idPatient = ? AND c.statut = 'validée'
    ORDER BY c.date DESC, c.heure DESC");
$consultations->execute([$id]);
$consultations = $consultations->fetchAll();

$rdvsTous = $pdo->prepare("SELECT c.date, c.heure, c.statut, m.nom AS medecin
    FROM consultation c
    JOIN medecin m ON c.idMedecin = m.idMedecin
    WHERE c.idPatient = ?
    ORDER BY c.date DESC, c.heure DESC");
$rdvsTous->execute([$id]);
$rdvsTous = $rdvsTous->fetchAll();

function getOrdonnancesParConsultation($pdo, $idConsultation)
{
    $stmt = $pdo->prepare("SELECT md.nom AS medicament, om.quantite, om.duree
        FROM ordonnance o
        JOIN ordonnance_medicament om ON o.idOrdonnance = om.idOrdonnance
        JOIN medicament md ON om.idMedicament = md.idMedicament
        WHERE o.idConsultation = ?");
    $stmt->execute([$idConsultation]);
    return $stmt->fetchAll();
}

function getAnalysesParConsultation($pdo, $idConsultation)
{
    $stmt = $pdo->prepare("SELECT typeAnalyse FROM resultatanalyse WHERE idConsultation = ?");
    $stmt->execute([$idConsultation]);
    return $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>TeleMed Pro - Dashboard Patient</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
    :root {
        --primary-blue: #0066cc;
        --secondary-blue: #4a90e2;
        --light-blue: #e8f4fd;
        --accent-green: #00b894;
        --light-green: #d1f2eb;
        --warning-orange: #ff7675;
        --light-orange: #fff5f5;
        --dark-blue: #2c3e50;
        --light-gray: #f8f9fa;
        --medium-gray: #6c757d;
        --border-color: #e9ecef;
        --white: #ffffff;
        --shadow: 0 4px 15px rgba(0, 102, 204, 0.1);
        --shadow-hover: 0 8px 25px rgba(0, 102, 204, 0.15);
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, var(--light-blue) 0%, var(--light-gray) 100%);
        min-height: 100vh;
    }

    header {
        background: linear-gradient(135deg, var(--primary-blue) 0%, var(--secondary-blue) 100%);
        color: white;
        padding: 20px 40px;
        position: relative;
        box-shadow: var(--shadow);
        z-index: 100;
    }

    .header-content {
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
    }

    .logo-container {
        position: absolute;
        left: 0;
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .logo {
        width: 60px;
        height: 60px;
        background: var(--white);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 15px rgba(255, 255, 255, 0.2);
    }

    .logo i {
        font-size: 30px;
        color: var(--primary-blue);
    }

    .brand-text {
        font-size: 18px;
        font-weight: 600;
        color: var(--white);
    }

    h1 {
        font-size: 28px;
        font-weight: 700;
        text-align: center;
    }

    nav {
        width: 280px;
        background: var(--white);
        position: fixed;
        top: 100px;
        left: 0;
        height: calc(100% - 100px);
        padding: 30px 0;
        box-shadow: var(--shadow);
        z-index: 50;
        overflow-y: auto;
    }

    .nav-header {
        padding: 0 20px 30px;
        text-align: center;
        border-bottom: 2px solid var(--border-color);
        margin-bottom: 20px;
    }

    .patient-avatar {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        box-shadow: var(--shadow);
    }

    .patient-avatar i {
        font-size: 35px;
        color: var(--white);
    }

    .patient-name {
        font-size: 16px;
        font-weight: 600;
        color: var(--dark-blue);
        margin-bottom: 5px;
    }

    .patient-status {
        font-size: 12px;
        color: var(--accent-green);
        background: var(--light-green);
        padding: 4px 12px;
        border-radius: 20px;
        display: inline-block;
    }

    nav a {
        display: flex;
        align-items: center;
        gap: 15px;
        color: var(--dark-blue);
        padding: 15px 20px;
        text-decoration: none;
        transition: all 0.3s ease;
        font-weight: 500;
        margin: 2px 10px;
        border-radius: 12px;
        position: relative;
    }

    nav a:hover {
        background: var(--light-blue);
        color: var(--primary-blue);
        transform: translateX(5px);
    }

    nav a.active {
        background: var(--primary-blue);
        color: var(--white);
        box-shadow: var(--shadow);
    }

    nav a i {
        font-size: 20px;
        width: 25px;
        text-align: center;
    }

    .logout-link {
        margin-top: auto;
        border-top: 2px solid var(--border-color);
        padding-top: 20px;
    }

    .logout-link a {
        color: var(--warning-orange) !important;
    }

    .logout-link a:hover {
        background: var(--light-orange) !important;
    }

    main {
        margin-left: 280px;
        padding: 40px;
        min-height: calc(100vh - 100px);
    }

    section {
        background: var(--white);
        padding: 40px;
        margin-bottom: 30px;
        border-radius: 20px;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }

    section:hover {
        box-shadow: var(--shadow-hover);
    }

    .section-header {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 3px solid var(--border-color);
    }

    .section-icon {
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .section-icon i {
        font-size: 24px;
        color: var(--white);
    }

    h2 {
        color: var(--dark-blue);
        font-size: 28px;
        font-weight: 700;
        margin: 0;
    }

    .welcome-section {
        text-align: center;
        background: linear-gradient(135deg, var(--light-blue) 0%, var(--white) 100%);
    }

    .welcome-image {
        width: 100%;
        max-height: 350px;
        object-fit: cover;
        border-radius: 15px;
        margin: 20px 0;
        box-shadow: var(--shadow);
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 30px;
        margin-top: 30px;
    }

    .feature-card {
        text-align: center;
        padding: 30px 20px;
        background: var(--white);
        border-radius: 15px;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .feature-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
        border-color: var(--primary-blue);
    }

    .feature-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 15px;
        background: linear-gradient(135deg, var(--accent-green), #00d2d3);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .feature-icon i {
        font-size: 35px;
        color: var(--white);
    }

    .feature-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--dark-blue);
        margin-bottom: 8px;
    }

    .feature-desc {
        font-size: 14px;
        color: var(--medium-gray);
    }

    form {
        background: var(--light-gray);
        padding: 30px;
        border-radius: 15px;
        border: 2px solid var(--border-color);
    }

    form input,
    form select,
    form button {
        padding: 15px 20px;
        margin: 10px 0;
        width: 100%;
        border: 2px solid var(--border-color);
        border-radius: 12px;
        font-size: 16px;
        font-family: 'Inter', sans-serif;
        transition: all 0.3s ease;
    }

    form input:focus,
    form select:focus {
        outline: none;
        border-color: var(--primary-blue);
        box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
    }

    form button {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
        color: white;
        border: none;
        cursor: pointer;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        transition: all 0.3s ease;
    }

    form button:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-hover);
    }

    form button i {
        font-size: 18px;
    }

    .hidden {
        display: none;
    }

    .modern-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: var(--shadow);
    }

    .modern-table th,
    .modern-table td {
        padding: 20px;
        text-align: left;
        border-bottom: 1px solid var(--border-color);
    }

    .modern-table th {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
        color: var(--white);
        font-weight: 600;
        text-transform: uppercase;
        font-size: 14px;
        letter-spacing: 0.5px;
    }

    .modern-table tr:hover {
        background: var(--light-blue);
    }

    .status-badge {
        padding: 6px 15px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }

    .status-validee {
        background: var(--light-green);
        color: var(--accent-green);
    }

    .status-en-attente {
        background: #fff3cd;
        color: #856404;
    }

    .status-annulee {
        background: var(--light-orange);
        color: var(--warning-orange);
    }

    .consultation-card {
        background: var(--white);
        border: 2px solid var(--border-color);
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 25px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .consultation-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 5px;
        height: 100%;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
    }

    .consultation-card:hover {
        border-color: var(--primary-blue);
        box-shadow: var(--shadow-hover);
    }

    .consultation-header {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }

    .consultation-icon {
        width: 50px;
        height: 50px;
        background: var(--accent-green);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .consultation-icon i {
        font-size: 20px;
        color: var(--white);
    }

    .consultation-info p {
        margin: 8px 0;
        font-size: 16px;
    }

    .consultation-info strong {
        color: var(--dark-blue);
        font-weight: 600;
    }

    .prescription-section,
    .analysis-section {
        margin-top: 20px;
        padding: 20px;
        background: var(--light-gray);
        border-radius: 12px;
        border-left: 4px solid var(--accent-green);
    }

    .prescription-section h4,
    .analysis-section h4 {
        color: var(--dark-blue);
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .prescription-section ul,
    .analysis-section ul {
        list-style: none;
    }

    .prescription-section li,
    .analysis-section li {
        padding: 10px 0;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .prescription-section li:last-child,
    .analysis-section li:last-child {
        border-bottom: none;
    }

    .prescription-section li i,
    .analysis-section li i {
        color: var(--accent-green);
        font-size: 16px;
    }

    .profile-card {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 30px;
        align-items: center;
    }

    .profile-avatar {
        width: 120px;
        height: 120px;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow);
    }

    .profile-avatar i {
        font-size: 50px;
        color: var(--white);
    }

    .profile-info p {
        margin: 15px 0;
        font-size: 18px;
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .profile-info i {
        color: var(--primary-blue);
        font-size: 20px;
        width: 25px;
    }

    @media (max-width: 768px) {
        nav {
            width: 100%;
            height: auto;
            position: relative;
            top: 0;
        }

        main {
            margin-left: 0;
            padding: 20px;
        }

        .header-content {
            flex-direction: column;
            gap: 15px;
        }

        .logo-container {
            position: static;
        }

        .features-grid {
            grid-template-columns: 1fr;
        }

        .profile-card {
            grid-template-columns: 1fr;
            text-align: center;
        }
    }
    </style>
</head>

<body>
    <header>
        <div class="header-content">
            <div class="logo-container">
                <div class="logo">
                    <i class="fas fa-heartbeat"></i>
                </div>
                <div class="brand-text">TeleMed Pro</div>
            </div>
            <h1><i class="fas fa-user-md"></i> Ma Santé en Ligne</h1>
        </div>
    </header>

    <nav>
        <div class="nav-header">
            <div class="patient-avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="patient-name"><?= htmlspecialchars($patient['prenom']) ?>
                <?= htmlspecialchars($patient['nom']) ?></div>
            <span class="patient-status"><i class="fas fa-check-circle"></i> Connecté</span>
        </div>

        <a href="#" onclick="showSection('accueil')" class="active">
            <i class="fas fa-home"></i> Accueil
        </a>
        <a href="#" onclick="showSection('rdv')">
            <i class="fas fa-calendar-plus"></i> Prendre un RDV
        </a>
        <a href="#" onclick="showSection('etat_rdv')">
            <i class="fas fa-calendar-check"></i> Mes Rendez-vous
        </a>
        <a href="#" onclick="showSection('consultations')">
            <i class="fas fa-stethoscope"></i> Mes Consultations
        </a>
        <a href="#" onclick="showSection('profil')">
            <i class="fas fa-user-circle"></i> Mon Profil
        </a>

        <div class="logout-link">
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i> Déconnexion
            </a>
        </div>
    </nav>

    <main>
        <section id="accueil" class="welcome-section">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-home"></i>
                </div>
                <h2>Bienvenue dans votre espace santé</h2>
            </div>

            <img src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80"
                alt="Télémédecine moderne" class="welcome-image">

            <p style="font-size: 18px; color: var(--medium-gray); margin: 20px 0; line-height: 1.6;">
                <i class="fas fa-shield-alt" style="color: var(--accent-green); margin-right: 10px;"></i>
                Votre santé connectée en toute sécurité. Gérez vos consultations, prescriptions et analyses médicales
                depuis un seul endroit, disponible 24h/24.
            </p>

            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-prescription-bottle-alt"></i>
                    </div>
                    <div class="feature-title">Ordonnances numériques</div>
                    <div class="feature-desc">Accédez à vos prescriptions</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="feature-title">Suivi médical</div>
                    <div class="feature-desc">Visualisez vos analyses</div>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="feature-title">Disponible 24/7</div>
                    <div class="feature-desc">Service accessible partout</div>
                </div>
            </div>
        </section>

        <section id="rdv" class="hidden">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-calendar-plus"></i>
                </div>
                <h2>Demande de Consultation</h2>
            </div>

            <form method="post" action="ajouter_consultation.php">
                <label for="medecin"
                    style="font-weight: 600; color: var(--dark-blue); margin-bottom: 10px; display: block;">
                    <i class="fas fa-user-md"></i> Choisir un médecin spécialiste :
                </label>
                <select name="idMedecin" required>
                    <option value="">-- Sélectionner un médecin --</option>
                    <?php foreach ($medecins as $m): ?>
                    <option value="<?= $m['idMedecin'] ?>">
                        Dr. <?= htmlspecialchars($m['nom']) ?> - <?= htmlspecialchars($m['specialite']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">
                    <i class="fas fa-paper-plane"></i>
                    Demander un rendez-vous
                </button>
            </form>
        </section>

        <section id="etat_rdv" class="hidden">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h2>Mes Rendez-vous</h2>
            </div>

            <table class="modern-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-calendar"></i> Date</th>
                        <th><i class="fas fa-clock"></i> Heure</th>
                        <th><i class="fas fa-user-md"></i> Médecin</th>
                        <th><i class="fas fa-info-circle"></i> Statut</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rdvsTous as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['date']) ?></td>
                        <td><?= htmlspecialchars($r['heure']) ?></td>
                        <td>Dr. <?= htmlspecialchars($r['medecin']) ?></td>
                        <td>
                            <span class="status-badge status-<?= str_replace(' ', '-', strtolower($r['statut'])) ?>">
                                <?= ucfirst(htmlspecialchars($r['statut'])) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <section id="consultations" class="hidden">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-stethoscope"></i>
                </div>
                <h2>Mes Consultations</h2>
            </div>

            <?php foreach ($consultations as $c): ?>
            <div class="consultation-card">
                <div class="consultation-header">
                    <div class="consultation-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div>
                        <h3 style="color: var(--dark-blue); margin-bottom: 5px;">
                            Dr. <?= htmlspecialchars($c['medecin']) ?>
                        </h3>
                        <p style="color: var(--medium-gray); font-size: 14px;">
                            <i class="fas fa-calendar"></i> <?= htmlspecialchars($c['date']) ?>
                            <i class="fas fa-clock" style="margin-left: 15px;"></i> <?= htmlspecialchars($c['heure']) ?>
                        </p>
                    </div>
                </div>

                <div class="consultation-info">
                    <p><strong><i class="fas fa-notes-medical"></i> Notes médicales :</strong>
                        <?= htmlspecialchars($c['notesMedecincrypte']) ?></p>
                </div>

                <?php $ordos = getOrdonnancesParConsultation($pdo, $c['idConsultation']); ?>
                <?php if ($ordos): ?>
                <div class="prescription-section">
                    <h4><i class="fas fa-prescription-bottle-alt"></i> Ordonnances prescrites</h4>
                    <ul>
                        <?php foreach ($ordos as $o): ?>
                        <li>
                            <i class="fas fa-pills"></i>
                            <span><?= htmlspecialchars($o['medicament']) ?> —
                                <?= $o['quantite'] ?> pendant <?= $o['duree'] ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php $anals = getAnalysesParConsultation($pdo, $c['idConsultation']); ?>
                <?php if ($anals): ?>
                <div class="analysis-section">
                    <h4><i class="fas fa-microscope"></i> Résultats d'Analyses</h4>
                    <ul>
                        <?php foreach ($anals as $a): ?>
                        <li>
                            <i class="fas fa-chart-bar"></i>
                            <span><?= htmlspecialchars($a['typeAnalyse']) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </section>

        <section id="profil" class="hidden">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-user-circle"></i>
                </div>
                <h2>Mon Profil Personnel</h2>
            </div>

            <div class="profile-card">
                <div class="profile-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="profile-info">
                    <p><i class="fas fa-id-card"></i>
                        <strong>Nom complet :</strong>
                        <?= htmlspecialchars($patient['nom']) ?> <?= htmlspecialchars($patient['prenom']) ?>
                    </p>
                    <p><i class="fas fa-envelope"></i>
                        <strong>Email :</strong>
                        <?= htmlspecialchars($patient['email']) ?>
                    </p>
                    <p><i class="fas fa-birthday-cake"></i>
                        <strong>Date de naissance :</strong>
                        <?= htmlspecialchars($patient['dateNaissance']) ?>
                    </p>
                </div>
            </div>
        </section>
    </main>

    <script>
    function showSection(id) {
        // Masquer toutes les sections
        const sections = document.querySelectorAll('main section');
        sections.forEach(section => {
            section.classList.toggle('hidden', section.id !== id);
        });

        // Mettre à jour les liens de navigation
        const navLinks = document.querySelectorAll('nav a');
        navLinks.forEach(link => {
            link.classList.remove('active');
        });

        // Ajouter la classe active au lien cliqué
        event.target.classList.add('active');
    }

    // Animation d'entrée pour les cartes
    document.addEventListener('DOMContentLoaded', function() {
        const cards = document.querySelectorAll('.feature-card, .consultation-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });

        // Animation pour les éléments du tableau
        const tableRows = document.querySelectorAll('.modern-table tbody tr');
        tableRows.forEach((row, index) => {
            row.style.opacity = '0';
            row.style.transform = 'translateX(-20px)';
            setTimeout(() => {
                row.style.transition = 'all 0.4s ease';
                row.style.opacity = '1';
                row.style.transform = 'translateX(0)';
            }, index * 50);
        });
    });

    // Effet de notification pour les nouvelles actions
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? 'var(--accent-green)' : 'var(--warning-orange)'};
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: var(--shadow);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        notification.innerHTML =
            `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => document.body.removeChild(notification), 300);
        }, 3000);
    }

    // Ajouter les animations CSS
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .pulse-animation {
            animation: pulse 2s infinite;
        }
    `;
    document.head.appendChild(style);
    </script>
</body>

</html>cript>
</body>

</html>