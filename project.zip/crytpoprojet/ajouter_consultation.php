<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['idPatient'])) {
    $idPatient = $_SESSION['idPatient'];
    $idMedecin = $_POST['idMedecin'];

    // Rechercher un créneau disponible
    $stmt = $pdo->prepare("SELECT date, heure FROM planning_medecin WHERE idMedecin = ? AND estDisponible = 1 ORDER BY date, heure LIMIT 1");
    $stmt->execute([$idMedecin]);
    $creneau = $stmt->fetch();

    if ($creneau) {
        // Réserver le créneau
        $pdo->prepare("UPDATE planning_medecin SET estDisponible = 0 WHERE idMedecin = ? AND date = ? AND heure = ?")
            ->execute([$idMedecin, $creneau['date'], $creneau['heure']]);

        // Insérer la demande de consultation
        $pdo->prepare("INSERT INTO consultation (date, heure, idMedecin, idPatient, statut) VALUES (?, ?, ?, ?, 'en_attente')")
            ->execute([$creneau['date'], $creneau['heure'], $idMedecin, $idPatient]);

        header("Location: dashboard_patient.php");
        exit;
    } else {
        echo "Aucun créneau disponible pour ce médecin.";
    }
}