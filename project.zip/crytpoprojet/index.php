<?php
session_start();
require_once 'config.php';
$error = '';
$success = '';

// Handle login form submission
if (isset($_POST['loginSubmit'])) {
    $email = trim($_POST['loginEmail']);
    $password = $_POST['loginPassword'];
    
    // Basic validation
    if (empty($email) || empty($password)) {
        $error = "Veuillez remplir tous les champs.";
    } else {
        try {
            // Prepare statement to find user by email
            $stmt = $pdo->prepare("SELECT idPatient, nom, prenom, email, password FROM patient WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // Verify password (using password hashing)
                if (password_verify($password, $user['password'])) {
                    // Login successful
                    $_SESSION['user_id'] = $user['idPatient'];
                    $_SESSION['idPatient'] = $user['idPatient'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_name'] = $user['prenom'] . ' ' . $user['nom'];
                    $_SESSION['logged_in'] = true;
                    
                    // Redirect to dashboard
                    header("Location: dashboard_patient.php");
                    exit();
                    
                } else {
                    $error = "Email ou mot de passe invalide.";
                }
            } else {
                $error = "Email ou mot de passe invalide.";
            }
            
        } catch (PDOException $e) {
            $error = "Erreur de base de données. Veuillez réessayer plus tard.";
            // Log the actual error for debugging
            error_log("Login error: " . $e->getMessage());
        }
    }
}

// Handle registration form submission
if (isset($_POST['registerSubmit'])) {
    $nom = trim($_POST['registerNom']);
    $prenom = trim($_POST['registerPrenom']);
    $email = trim($_POST['registerEmail']);
    $password = $_POST['registerPassword'];
    $confirmPassword = $_POST['confirmPassword'];
    $birthdate = $_POST['registerBirthdate'];
    $termsAccepted = isset($_POST['termsAccepted']);
    
    // Basic validation
    if (empty($nom) || empty($prenom) || empty($email) || empty($password) || empty($confirmPassword) || empty($birthdate)) {
        $error = "Veuillez remplir tous les champs.";
    } elseif ($password !== $confirmPassword) {
        $error = "Les mots de passe ne correspondent pas.";
    } elseif (strlen($password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif (!$termsAccepted) {
        $error = "Veuillez accepter les conditions générales.";
    } else {
        try {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT email FROM patient WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $error = "Cet email existe déjà. Veuillez utiliser un autre email.";
            } else {
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert new patient
                $stmt = $pdo->prepare("INSERT INTO patient (nom, prenom, email, password, dateNaissance) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$nom, $prenom, $email, $hashedPassword, $birthdate]);
                
                $success = "Compte créé avec succès ! Vous pouvez maintenant vous connecter.";
            }
            
        } catch (PDOException $e) {
            $error = "Erreur de base de données. Veuillez réessayer plus tard.";
            error_log("Registration error: " . $e->getMessage());
        }
    }
}

// Check if user is already logged in
$isLoggedIn = isset($_SESSION['logged_in']) && $_SESSION['logged_in'];

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Display messages
if (isset($_GET['login']) && $_GET['login'] == 'success') {
    $success = "Connexion réussie ! Bon retour.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Site Médical</title>
    <link rel="stylesheet" href="styles.css" />
    <style>
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }
        .input-group input[type="date"] {
            padding: 12px 0 8px 0;
            border: none;
            border-bottom: 2px solid #ddd;
            background: transparent;
            width: 100%;
            font-size: 16px;
            color: #333;
        }
        .input-group input[type="date"]:focus {
            outline: none;
            border-bottom-color: #007bff;
        }
        .input-group label {
            position: absolute;
            top: 12px;
            left: 0;
            color: #999;
            transition: all 0.3s ease;
            pointer-events: none;
        }
        .input-group input[type="date"]:focus + label,
        .input-group input[type="date"]:valid + label {
            top: -8px;
            font-size: 12px;
            color: #007bff;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .name-row {
            display: flex;
            gap: 15px;
        }
        .name-row .input-group {
            flex: 1;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            
            <?php if ($isLoggedIn): ?>
                <!-- Redirect to dashboard if already logged in -->
                <script>
                    window.location.href = 'dashboard_patient.php';
                </script>
                
            <?php else: ?>
                
                <!-- Display error/success messages -->
                <?php if (!empty($error)): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <!-- LOGIN FORM -->
                <div class="form login-form active" id="loginForm">
                    <h2 class="form-title">Bon retour</h2>
                    <p class="form-subtitle">Connectez-vous à votre compte</p>
                    
                    <form action="index.php" method="POST">
                        <div class="input-group">
                            <input type="email" id="loginEmail" name="loginEmail" required />
                            <label for="loginEmail">Adresse Email</label>
                            <span class="input-highlight"></span>
                        </div>
                        
                        <div class="input-group">
                            <input type="password" id="loginPassword" name="loginPassword" required />
                            <label for="loginPassword">Mot de passe</label>
                            <span class="input-highlight"></span>
                        </div>
                        
                        <div class="form-options">
                            <a href="#" class="forgot-password">Mot de passe oublié ?</a>
                        </div>
                        
                        <button type="submit" name="loginSubmit" class="btn btn-primary">Se connecter</button>
                    </form>
                    
                    <div class="form-footer">
                        <p>Vous n'avez pas de compte ? <a href="#" class="toggle-form" onclick="showRegister()">S'inscrire</a></p>
                    </div>
                </div>
                
                <!-- REGISTER FORM -->
                <div class="form register-form" id="registerForm">
                    <h2 class="form-title">Créer un compte</h2>
                    <p class="form-subtitle">Rejoignez-nous aujourd'hui</p>
                    
                    <form action="index.php" method="POST">
                        <div class="name-row">
                            <div class="input-group">
                                <input type="text" id="registerPrenom" name="registerPrenom" required />
                                <label for="registerPrenom">Prénom</label>
                                <span class="input-highlight"></span>
                            </div>
                            
                            <div class="input-group">
                                <input type="text" id="registerNom" name="registerNom" required />
                                <label for="registerNom">Nom</label>
                                <span class="input-highlight"></span>
                            </div>
                        </div>
                        
                        <div class="input-group">
                            <input type="email" id="registerEmail" name="registerEmail" required />
                            <label for="registerEmail">Adresse Email</label>
                            <span class="input-highlight"></span>
                        </div>
                        
                        <div class="input-group">
                            <input type="date" id="registerBirthdate" name="registerBirthdate" required />
                            <label for="registerBirthdate">Date de naissance</label>
                            <span class="input-highlight"></span>
                        </div>
                        
                        <div class="input-group">
                            <input type="password" id="registerPassword" name="registerPassword" required />
                            <label for="registerPassword">Mot de passe</label>
                            <span class="input-highlight"></span>
                        </div>
                        
                        <div class="input-group">
                            <input type="password" id="confirmPassword" name="confirmPassword" required />
                            <label for="confirmPassword">Confirmer le mot de passe</label>
                            <span class="input-highlight"></span>
                        </div>
                        
                        <div class="form-options">
                            <label class="checkbox-container">
                                <input type="checkbox" name="termsAccepted" required />
                                <span class="checkmark"></span>
                                J'accepte les conditions générales
                            </label>
                        </div>
                        
                        <button type="submit" name="registerSubmit" class="btn btn-primary">Créer le compte</button>
                    </form>
                    
                    <div class="form-footer">
                        <p>Vous avez déjà un compte ? <a href="#" class="toggle-form" onclick="showLogin()">Se connecter</a></p>
                    </div>
                </div>
                
            <?php endif; ?>
            
        </div>
    </div>
    
    <script>
        function showLogin() {
            document.getElementById('loginForm').classList.add('active');
            document.getElementById('registerForm').classList.remove('active');
        }
        
        function showRegister() {
            document.getElementById('registerForm').classList.add('active');
            document.getElementById('loginForm').classList.remove('active');
        }
        
        // Auto-show login form if there's a registration success message
        <?php if (!empty($success) && strpos($success, 'créé') !== false): ?>
            showLogin();
        <?php endif; ?>
    </script>
</body>
</html>