-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 02 juin 2025 à 21:21
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_crypto`
--

-- --------------------------------------------------------

--
-- Structure de la table `consultation`
--

CREATE TABLE `consultation` (
  `idConsultation` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `notesMedecincrypte` text DEFAULT NULL,
  `idMedecin` int(11) NOT NULL,
  `idPatient` int(11) NOT NULL,
  `statut` varchar(50) DEFAULT 'en_attente',
  `heure` time DEFAULT '09:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `consultation`
--

INSERT INTO `consultation` (`idConsultation`, `date`, `notesMedecincrypte`, `idMedecin`, `idPatient`, `statut`, `heure`) VALUES
(5, '2025-06-06 00:00:00', 'Présente une fièvre persistante avec toux. Prescription d’antibiotiques.', 2, 6, 'validée', '09:30:00'),
(6, '2025-06-07 00:00:00', NULL, 2, 6, 'en_attente', '09:00:00'),
(7, '2025-06-07 00:00:00', NULL, 2, 6, 'en_attente', '10:00:00'),
(8, '2025-06-07 00:00:00', NULL, 3, 7, 'en_attente', '09:30:00');

-- --------------------------------------------------------

--
-- Structure de la table `medecin`
--

CREATE TABLE `medecin` (
  `idMedecin` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `specialite` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('medecin') DEFAULT 'medecin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `medecin`
--

INSERT INTO `medecin` (`idMedecin`, `nom`, `specialite`, `email`, `password`, `role`) VALUES
(2, 'medecin1', 'ophtalmologue ', 'medecin1@gmail.com', '123', 'medecin'),
(3, 'medecin2', 'dentiste', 'medecin2@gmail.com', '1234', 'medecin');

-- --------------------------------------------------------

--
-- Structure de la table `medicament`
--

CREATE TABLE `medicament` (
  `idMedicament` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `medicament`
--

INSERT INTO `medicament` (`idMedicament`, `nom`, `description`) VALUES
(1, 'Amoxicilline', 'Antibiotique à large spectre'),
(2, 'Doliprane', 'Antalgique et antipyrétique');

-- --------------------------------------------------------

--
-- Structure de la table `ordonnance`
--

CREATE TABLE `ordonnance` (
  `idOrdonnance` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `idMedecin` int(11) NOT NULL,
  `idPatient` int(11) NOT NULL,
  `idConsultation` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ordonnance`
--

INSERT INTO `ordonnance` (`idOrdonnance`, `date`, `idMedecin`, `idPatient`, `idConsultation`) VALUES
(1, '2025-06-06 00:00:00', 2, 6, 5);

-- --------------------------------------------------------

--
-- Structure de la table `ordonnance_medicament`
--

CREATE TABLE `ordonnance_medicament` (
  `idOrdonnance` int(11) NOT NULL,
  `idMedicament` int(11) NOT NULL,
  `quantite` varchar(100) NOT NULL,
  `duree` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ordonnance_medicament`
--

INSERT INTO `ordonnance_medicament` (`idOrdonnance`, `idMedicament`, `quantite`, `duree`) VALUES
(1, 1, '3 comprimés/jour', '7 jours'),
(1, 2, '2 comprimés/jour', '5 jours');

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

CREATE TABLE `patient` (
  `idPatient` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `dateNaissance` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`idPatient`, `nom`, `prenom`, `dateNaissance`, `email`, `password`) VALUES
(6, 'patient1', 'patient1', '2025-05-09', 'patient5@gmail.com', '$2y$10$OThX6tqYpPqb0I8xw0T4hu.Zl9Lkp/XYImLl2fjEzgfPDt7W61zWW'),
(7, 'patient2', 'patient2', '2025-06-13', 'patient2@gmail.com', '$2y$10$KTOboiGFh18IFsyoeeYK6.cM0ciF.9Qchvu53CGq3WKu8T2BWNMAG');

-- --------------------------------------------------------

--
-- Structure de la table `planning_medecin`
--

CREATE TABLE `planning_medecin` (
  `idPlanning` int(11) NOT NULL,
  `idMedecin` int(11) NOT NULL,
  `date` date NOT NULL,
  `heure` time NOT NULL,
  `estDisponible` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `planning_medecin`
--

INSERT INTO `planning_medecin` (`idPlanning`, `idMedecin`, `date`, `heure`, `estDisponible`) VALUES
(16, 2, '2025-06-07', '09:00:00', 0),
(19, 2, '2025-06-07', '10:00:00', 0),
(21, 3, '2025-06-07', '09:30:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `resultatanalyse`
--

CREATE TABLE `resultatanalyse` (
  `idResultat` int(11) NOT NULL,
  `typeAnalyse` varchar(100) NOT NULL,
  `donneesCryptees` longblob NOT NULL,
  `idConsultation` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `resultatanalyse`
--

INSERT INTO `resultatanalyse` (`idResultat`, `typeAnalyse`, `donneesCryptees`, `idConsultation`) VALUES
(1, 'Hémogramme complet', 0x4cc3a967c3a87265206175676d656e746174696f6e2064657320676c6f62756c657320626c616e6373, 5);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`idConsultation`),
  ADD KEY `idMedecin` (`idMedecin`),
  ADD KEY `idPatient` (`idPatient`);

--
-- Index pour la table `medecin`
--
ALTER TABLE `medecin`
  ADD PRIMARY KEY (`idMedecin`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `medicament`
--
ALTER TABLE `medicament`
  ADD PRIMARY KEY (`idMedicament`);

--
-- Index pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  ADD PRIMARY KEY (`idOrdonnance`),
  ADD KEY `idMedecin` (`idMedecin`),
  ADD KEY `idPatient` (`idPatient`),
  ADD KEY `fk_ordonnance_consultation` (`idConsultation`);

--
-- Index pour la table `ordonnance_medicament`
--
ALTER TABLE `ordonnance_medicament`
  ADD PRIMARY KEY (`idOrdonnance`,`idMedicament`),
  ADD KEY `idMedicament` (`idMedicament`);

--
-- Index pour la table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`idPatient`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `planning_medecin`
--
ALTER TABLE `planning_medecin`
  ADD PRIMARY KEY (`idPlanning`),
  ADD KEY `idMedecin` (`idMedecin`);

--
-- Index pour la table `resultatanalyse`
--
ALTER TABLE `resultatanalyse`
  ADD PRIMARY KEY (`idResultat`),
  ADD UNIQUE KEY `idConsultation` (`idConsultation`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `idConsultation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `medecin`
--
ALTER TABLE `medecin`
  MODIFY `idMedecin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `medicament`
--
ALTER TABLE `medicament`
  MODIFY `idMedicament` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  MODIFY `idOrdonnance` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `patient`
--
ALTER TABLE `patient`
  MODIFY `idPatient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `planning_medecin`
--
ALTER TABLE `planning_medecin`
  MODIFY `idPlanning` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT pour la table `resultatanalyse`
--
ALTER TABLE `resultatanalyse`
  MODIFY `idResultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `consultation_ibfk_1` FOREIGN KEY (`idMedecin`) REFERENCES `medecin` (`idMedecin`),
  ADD CONSTRAINT `consultation_ibfk_2` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`idPatient`);

--
-- Contraintes pour la table `ordonnance`
--
ALTER TABLE `ordonnance`
  ADD CONSTRAINT `fk_ordonnance_consultation` FOREIGN KEY (`idConsultation`) REFERENCES `consultation` (`idConsultation`),
  ADD CONSTRAINT `ordonnance_ibfk_1` FOREIGN KEY (`idMedecin`) REFERENCES `medecin` (`idMedecin`),
  ADD CONSTRAINT `ordonnance_ibfk_2` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`idPatient`);

--
-- Contraintes pour la table `ordonnance_medicament`
--
ALTER TABLE `ordonnance_medicament`
  ADD CONSTRAINT `ordonnance_medicament_ibfk_1` FOREIGN KEY (`idOrdonnance`) REFERENCES `ordonnance` (`idOrdonnance`),
  ADD CONSTRAINT `ordonnance_medicament_ibfk_2` FOREIGN KEY (`idMedicament`) REFERENCES `medicament` (`idMedicament`);

--
-- Contraintes pour la table `planning_medecin`
--
ALTER TABLE `planning_medecin`
  ADD CONSTRAINT `planning_medecin_ibfk_1` FOREIGN KEY (`idMedecin`) REFERENCES `medecin` (`idMedecin`);

--
-- Contraintes pour la table `resultatanalyse`
--
ALTER TABLE `resultatanalyse`
  ADD CONSTRAINT `resultatanalyse_ibfk_1` FOREIGN KEY (`idConsultation`) REFERENCES `consultation` (`idConsultation`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
