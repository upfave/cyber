<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $motdepasse = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM patient WHERE email = ?");
    $stmt->execute([$email]);
    $patient = $stmt->fetch();

    if ($patient && password_verify($motdepasse, $patient['password'])) {
        $_SESSION['idPatient'] = $patient['idPatient'];
        $_SESSION['prenom'] = $patient['prenom'];
        header("Location: dashboard_patient.php");
        exit;
    } else {
        echo "Email ou password incorrect.";
    }
}
